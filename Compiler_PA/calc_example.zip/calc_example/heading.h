#define YY_NO_UNPUT
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>

using namespace std;

